package com.example.ha4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class MainActivity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        Intent intent = getIntent();
        String cId = intent.getStringExtra("cid");
        RequestQueue queue = Volley.newRequestQueue(MainActivity3.this);
        String url = "http://10.0.2.2:8080/loyaltyfirst/Transactions.jsp?cid="+cId;
        TextView textView = findViewById(R.id.textView5);
        StringRequest request = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String s) {
                String res="";
                String response = s.trim();
                String[] transactions = response.split("#");
                res += "TXN_Ref                    Date                           Points             Total\n";
                res += "_____________________________________________________________\n";
                for(String str: transactions){
                    String[] trns = str.split(",");
                    String trId = trns[0];
                    String date= trns[1];
                    String points = trns[2];
                    String total = trns[3];
                    res += String.format("%-20s  %-20s  %-20s  %-20s\n", trId, date, points, total);
                }
                res += "____________________________________________________________\n";
                textView.setText(res);
            }
        }, null);
        queue.add(request);
    }
}