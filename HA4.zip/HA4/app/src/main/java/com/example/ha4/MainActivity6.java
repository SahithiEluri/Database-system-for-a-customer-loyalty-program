package com.example.ha4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class MainActivity6 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);
        Spinner spinner = findViewById(R.id.spinner3);
        TextView textView12 = findViewById(R.id.textView12);
        TextView textView13 = findViewById(R.id.textView13);
        TextView textView14 = findViewById(R.id.textView14);
        Button button7 = findViewById(R.id.button7);
        Intent intent = getIntent();
        String cId = intent.getStringExtra("cid");
        String percentAdded = "";
        String points = "";
        ArrayList<String> list = new ArrayList<String>();
        RequestQueue queue = Volley.newRequestQueue(MainActivity6.this);
        String url = "http://10.0.2.2:8080/loyaltyfirst/Transactions.jsp?cid="+cId;
        StringRequest request = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String s) {
                String response = s.trim();
                String[] transactions = response.split("#");
                for(String str: transactions){
                    String[] trns = str.split(",");
                    String trId = trns[0];
                    list.add(trId);
                }
                ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity6.this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, list);
                spinner.setAdapter(adapter);
            }
        }, null);
        queue.add(request);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String transacId = parent.getSelectedItem().toString();
                String url1 = "http://10.0.2.2:8080/loyaltyfirst/SupportFamilyIncrease.jsp?tref="+transacId+"&cid="+cId;
                StringRequest request1 = new StringRequest(Request.Method.GET, url1, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String s) {
                        String response1 = s.trim();
                        String[] familyDetails = response1.split(",");
                        textView12.setText(familyDetails[2]);
                        textView13.setText(familyDetails[0]);
                        textView14.setText(familyDetails[1]);
                    }
                }, null);
                queue.add(request1);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url2 = "http://10.0.2.2:8080/loyaltyfirst/FamilyIncrease.jsp?fid="+textView13.getText()+"&cid="+cId+"&npoints="+textView12.getText();
                StringRequest request2 = new StringRequest(Request.Method.GET, url2, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String s) {
                        Toast.makeText(MainActivity6.this, s.trim(), Toast.LENGTH_LONG).show();
                    }
                }, null);
                queue.add(request2);
            }
        });
    }
}