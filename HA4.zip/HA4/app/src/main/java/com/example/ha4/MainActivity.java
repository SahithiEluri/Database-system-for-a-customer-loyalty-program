package com.example.ha4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button = findViewById(R.id.button);
        EditText editText = findViewById(R.id.editTextText);
        EditText editText2 = findViewById(R.id.editTextText2);
        button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                //Toast.makeText(MainActivity.this, "Yes", Toast.LENGTH_LONG).show();
                RequestQueue queue = Volley.newRequestQueue(MainActivity.this);
                String pass = editText.getText().toString();
                String user = editText2.getText().toString();
                String url = "http://10.0.2.2:8080/loyaltyfirst/login?user="+user+"&pass="+pass;
                StringRequest request = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String s) {
                        //Toast.makeText(MainActivity.this, s, Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                        if(s.contains("Yes")){
                            String response = s.trim();
                            String[] ids = response.split(":");
                            intent.putExtra("cid", ids[1]);
                            startActivity(intent);
                        } else if (s.contains("No")) {
                            //intent.putExtra("status", "No");
                        }

                    }
                }, null);
                queue.add(request);
            }
        });
    }
}