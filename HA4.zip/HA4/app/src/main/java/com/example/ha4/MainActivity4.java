package com.example.ha4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.ArrayList;

public class MainActivity4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        Spinner spinner = findViewById(R.id.spinner);
        TextView textView = findViewById(R.id.textView6);
        TextView textView7 = findViewById(R.id.textView7);
        TextView textView8 = findViewById(R.id.textView8);
        Intent intent = getIntent();
        String cId = intent.getStringExtra("cid");
        ArrayList<String> list = new ArrayList<String>();
        RequestQueue queue = Volley.newRequestQueue(MainActivity4.this);
        String url = "http://10.0.2.2:8080/loyaltyfirst/Transactions.jsp?cid="+cId;
        StringRequest request = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String s) {
                String response = s.trim();
                String[] transactions = response.split("#");
                for(String str: transactions){
                    String[] trns = str.split(",");
                    String trId = trns[0];
                    list.add(trId);
                }
                ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity4.this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, list);
                spinner.setAdapter(adapter);
            }
        }, null);
        queue.add(request);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String tref = parent.getSelectedItem().toString();
                String url1 = "http://10.0.2.2:8080/loyaltyfirst/TransactionDetails.jsp?tref="+tref;
                StringRequest request1 = new StringRequest(Request.Method.GET, url1, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String s) {
                        String res="";
                        String response1 = s.trim();
                        String[] transactionsDetails = response1.split("#");
                        //res += "ProductName                                    Quantity                       Points\n";
                        res += String.format("%-40s    %-10s     %-10s\n", "ProductName", "Quantity", "Points");
                        res += "____________________________________________________________\n";
                        String date="";
                        String mainP="";

                        for(String str: transactionsDetails){
                            String[] trns = str.split(",");
                            String ProductName = trns[2];
                            String quantity = trns[4];
                            String points = trns[3];
                            date = trns[0];
                            mainP = trns[1];
                            res += String.format("%-40s    %-10s     %-10s\n", ProductName, quantity, points);
                        }
                        res += "____________________________________________________________\n";
                        textView.setText(res);
                        textView7.setText(date);
                        textView8.setText(mainP);
                    }
                }, null);
                queue.add(request1);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
}