package com.example.ha4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.ArrayList;

public class MainActivity5 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);
        Spinner spinner = findViewById(R.id.spinner2);
        TextView textView9 = findViewById(R.id.textView9);
        TextView textView10 = findViewById(R.id.textView10);
        TextView textView11 = findViewById(R.id.textView11);
        Intent intent = getIntent();
        String cId = intent.getStringExtra("cid");
        ArrayList<String> list = new ArrayList<String>();
        RequestQueue queue = Volley.newRequestQueue(MainActivity5.this);
        String url = "http://10.0.2.2:8080/loyaltyfirst/PrizeIds.jsp?cid="+cId;
        StringRequest request = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String s) {
                String response = s.trim();
                String[] prizeIds = response.split("#");
                for(String str: prizeIds){
                    list.add(str);
                }
                ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity5.this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, list);
                spinner.setAdapter(adapter);
            }
        },null);
        queue.add(request);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String prizeId = parent.getSelectedItem().toString();
                String url1 = "http://10.0.2.2:8080/loyaltyfirst/RedemptionDetails.jsp?prizeid="+prizeId+"&cid="+cId;
                StringRequest request1 = new StringRequest(Request.Method.GET, url1, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String s) {
                        String res="";
                        String response1 = s.trim();
                        String[] prizeDetails = response1.split("#");
                        res += "Redemption_Date                  Exchange_Center\n";
                        res += "_________________________________________________\n";
                        String desc="";
                        String point="";
                        for(String str: prizeDetails){
                            String[] prize = str.split(",");
                            desc = prize[0];
                            point = prize[1];
                            String date = prize[2];
                            String center = prize[3];
                            res += String.format("%-40s  %-40s\n", date, center);
                        }
                        res += "_________________________________________________\n";
                        textView11.setText(res);
                        textView9.setText(desc);
                        textView10.setText(point);
                    }
                }, null);
                queue.add(request1);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
}